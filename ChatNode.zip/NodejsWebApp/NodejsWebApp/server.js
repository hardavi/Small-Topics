'use strict';
/*
const express=require("express");
const socket=require("socket.io");

//App Setup
const PORT=5000;
const app=express();
const server=app.listen(PORT,function(){
    console.log('Listening on PORT ${PORT}');
    console.log('http:localhost:${PORT}');
});

//Static file
app.use(express.static(server));

//Socket setup
const io=socket(server);

io.on("connection",function(socket){
    console.log("Made socket connection");
});

*/

const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
    console.log('a User connected');

    /*socket.on('disconnect',()=>{
        console.log('user disconnected');
    })*/
    socket.on('chat message', (msg) => {
        io.emit('chat message', msg);
        console.log('message:- ' + msg);
    });
});
http.listen(3000, () => {
    console.log('listening on port :- 3000');
});

