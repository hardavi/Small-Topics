﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterBtnClickShowData
{
    public partial class Defaults : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateData();
            }
        }

       
        private void PopulateData()
        {
            using (MasterDetailsBtnDBEntities mb = new MasterDetailsBtnDBEntities())
            {
                var v = mb.Customers.ToList();
                ListView1.DataSource = v;
                ListView1.DataBind();
            }
        }

        protected void ListView1_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                ListViewDataItem lv = (ListViewDataItem)e.Item;
                Customer c = (Customer)lv.DataItem;

                if (c != null)
                {
                    GridView gv = (GridView)e.Item.FindControl("GridView1");
                    if (gv != null)
                    {
                        using (MasterDetailsBtnDBEntities mb = new MasterDetailsBtnDBEntities())
                        {
                            var v = mb.OrderMasters.Where(a => a.CID.Equals(c.CID)).ToList();
                            gv.DataSource = v;
                            gv.DataBind();

                        }
                    }
                }
            }
        }
    }
}